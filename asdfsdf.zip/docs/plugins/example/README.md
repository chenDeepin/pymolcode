# Example Plugin

Copy this folder into `~/.pymolcode/plugins/example-plugin/` to test plugin loading.

Expected structure:

```text
~/.pymolcode/plugins/
  example-plugin/
    plugin.json
    plugin.py
```

The plugin exports:

- Tool: `example.echo`
- Skill: `example.skill`
