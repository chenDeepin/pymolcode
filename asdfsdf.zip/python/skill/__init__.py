"""Skill system for pymolcode drug discovery workflows."""

from __future__ import annotations
