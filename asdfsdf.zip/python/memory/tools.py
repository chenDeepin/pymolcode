"""Memory tools for the LLM agent.

These tools allow the agent to:
- Read from persistent memory (lessons learned, preferences, knowledge)
- Write new memories to avoid repeating mistakes
- Search and filter memories by tags, sections, or keywords

The memory system is designed to help the agent:
1. Learn from past mistakes (e.g., reporting success when operations failed)
2. Remember user preferences (e.g., preferred color schemes)
3. Store domain knowledge (e.g., PyMOL best practices)
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field

from .policy import MemoryPolicy


class MemoryReadInput(BaseModel):
    """Input schema for memory_read tool."""

    path: Optional[str] = Field(
        default=None,
        description="Path to MEMORY.md file (defaults to workspace memory)",
    )
    section: Optional[str] = Field(
        default=None,
        description="Read specific section only (e.g., 'lessons', 'preferences', 'knowledge')",
    )
    entry_id: Optional[str] = Field(
        default=None,
        description="Read specific entry by ID",
    )
    tags: Optional[list[str]] = Field(
        default=None,
        description="Search entries by tags",
    )
    keywords: Optional[list[str]] = Field(
        default=None,
        description="Search entries by keywords in content",
    )
    limit: int = Field(
        default=20,
        description="Max number of entries to return",
    )


class MemoryWriteInput(BaseModel):
    """Input schema for memory_write tool."""

    operation: str = Field(
        description="Operation: 'create', 'update', 'delete', or 'append'",
    )
    section: Optional[str] = Field(
        default=None,
        description="Section for create (e.g., 'lessons', 'preferences', 'knowledge')",
    )
    entry_id: Optional[str] = Field(
        default=None,
        description="Entry ID for update/delete/append",
    )
    data: Optional[dict[str, Any]] = Field(
        default=None,
        description="Entry data (key-value pairs)",
    )
    description: Optional[str] = Field(
        default=None,
        description="Entry description or context",
    )
    tags: Optional[list[str]] = Field(
        default=None,
        description="Entry tags for categorization",
    )


class MemoryReadTool:
    """Tool for reading from persistent memory storage."""

    name = "memory_read"
    description = """Read from persistent memory storage.

    Use this tool to:
    - Recall lessons learned from past mistakes
    - Look up user preferences
    - Access stored domain knowledge
    - Find relevant memories by tags or keywords

    Memories are organized into sections: 'lessons', 'preferences', 'knowledge'.
    """

    def __init__(
        self,
        memory_path: Optional[Path] = None,
        policy: Optional[MemoryPolicy] = None,
    ) -> None:
        self.memory_path = memory_path or Path("memory/MEMORY.md")
        self.policy = policy or MemoryPolicy()
        self._input_schema = MemoryReadInput

    def get_input_schema(self) -> dict[str, Any]:
        """Return the input schema for the tool."""
        return self._input_schema.model_json_schema()

    async def execute(self, **kwargs: Any) -> str:
        """Execute the memory read operation."""
        params = MemoryReadInput(**kwargs)
        memory_path = self._resolve_path(params.path)

        if not memory_path.exists():
            return f"Memory file not found at {memory_path}. Initialize memory first."

        try:
            content = await asyncio.to_thread(memory_path.read_text)
            entries = self._parse_memory(content)

            # Filter based on criteria
            if params.entry_id:
                entries = [e for e in entries if e.get("id") == params.entry_id]
            elif params.section:
                entries = [e for e in entries if e.get("section") == params.section]

            if params.tags:
                entries = [e for e in entries if self._matches_tags(e, params.tags)]

            if params.keywords:
                entries = [e for e in entries if self._matches_keywords(e, params.keywords)]

            # Apply limit
            entries = entries[: params.limit]

            if not entries:
                return "No memories found matching the criteria."

            return self._format_results(entries)

        except Exception as e:
            return f"Error reading memory: {e}"

    def _resolve_path(self, path: Optional[str]) -> Path:
        """Resolve memory file path."""
        if path:
            return Path(path)
        return self.memory_path

    def _parse_memory(self, content: str) -> list[dict[str, Any]]:
        """Parse memory Markdown content into structured entries."""
        entries: list[dict[str, Any]] = []
        lines = content.splitlines()

        current_section: Optional[str] = None
        current_entry: Optional[dict[str, Any]] = None
        current_description: list[str] = []

        for line in lines:
            # Section header: "## section-name"
            if line.startswith("## ") and not line.startswith("### "):
                if current_entry:
                    self._finalize_entry(current_entry, current_description, entries)
                    current_entry = None
                    current_description = []
                current_section = line[3:].strip()

            # Entry header: "### entry-id"
            elif line.startswith("### "):
                if current_entry:
                    self._finalize_entry(current_entry, current_description, entries)
                entry_id = line[4:].strip()
                current_entry = {
                    "id": entry_id,
                    "section": current_section,
                }
                current_description = []

            # Data field: "- **key**: value"
            elif current_entry and line.strip().startswith("- **"):
                match = line.strip()[2:].split("**:", 1)
                if len(match) == 2:
                    key = match[0].strip()
                    value = match[1].strip().strip('"').strip("'")
                    current_entry[key] = value

            # Description line
            elif current_entry and line.strip() and not line.startswith("- **"):
                current_description.append(line.strip())

        # Finalize last entry
        if current_entry:
            self._finalize_entry(current_entry, current_description, entries)

        return entries

    def _finalize_entry(
        self,
        entry: dict[str, Any],
        description: list[str],
        entries: list[dict[str, Any]],
    ) -> None:
        """Finalize and add entry to list."""
        if description:
            entry["description"] = " ".join(description)
        entries.append(entry)

    def _matches_tags(self, entry: dict[str, Any], tags: list[str]) -> bool:
        """Check if entry matches any of the specified tags."""
        entry_tags_str = entry.get("tags", "")
        if isinstance(entry_tags_str, str):
            entry_tags = [t.strip().lower() for t in entry_tags_str.split(",")]
        else:
            entry_tags = []
        return any(tag.lower() in entry_tags for tag in tags)

    def _matches_keywords(self, entry: dict[str, Any], keywords: list[str]) -> bool:
        """Check if entry contains any of the specified keywords."""
        text = (
            str(entry.get("id", ""))
            + " "
            + str(entry.get("description", ""))
            + " "
            + str(entry.get("lesson", ""))
            + " "
            + str(entry.get("context", ""))
        ).lower()
        return any(keyword.lower() in text for keyword in keywords)

    def _format_results(self, entries: list[dict[str, Any]]) -> str:
        """Format entries for output."""
        output = []

        for entry in entries:
            output.append(f"### {entry.get('id', 'Unknown ID')}")
            output.append(f"**Section**: {entry.get('section', 'Unknown')}")

            # Display all data fields except special ones
            for key, value in entry.items():
                if key not in ["id", "section", "description"]:
                    output.append(f"- **{key}**: {value}")

            if entry.get("description"):
                output.append(f"**Description**: {entry.get('description')}")

            output.append("---")

        return "\n".join(output)


class MemoryWriteTool:
    """Tool for writing to persistent memory storage."""

    name = "memory_write"
    description = """Write to persistent memory storage.

    Use this tool to:
    - Record lessons learned from mistakes (CRITICAL for improvement)
    - Store user preferences for future sessions
    - Save important domain knowledge

    IMPORTANT: Always record mistakes and their corrections in the 'lessons' section.
    This helps prevent repeating the same errors in future conversations.

    Example for recording a lesson:
    {
        "operation": "create",
        "section": "lessons",
        "data": {
            "lesson": "Always verify PyMOL operations succeeded",
            "context": "Reported success when load actually failed",
            "fix": "Check object list after load operations"
        },
        "tags": ["critical", "verification", "pymol"]
    }
    """

    def __init__(
        self,
        memory_path: Optional[Path] = None,
        policy: Optional[MemoryPolicy] = None,
    ) -> None:
        self.memory_path = memory_path or Path("memory/MEMORY.md")
        self.policy = policy or MemoryPolicy()
        self._input_schema = MemoryWriteInput

    def get_input_schema(self) -> dict[str, Any]:
        """Return the input schema for the tool."""
        return self._input_schema.model_json_schema()

    async def execute(self, **kwargs: Any) -> str:
        """Execute the memory write operation."""
        params = MemoryWriteInput(**kwargs)
        memory_path = self._resolve_path(None)

        # Create file if it doesn't exist
        if not memory_path.exists():
            await self._initialize_memory_file(memory_path)

        # Read current content
        content = await asyncio.to_thread(memory_path.read_text)

        if params.operation == "create":
            return await self._create_entry(
                content, memory_path, params.section, params.data, params.description, params.tags
            )
        elif params.operation == "update":
            if not params.entry_id:
                return "Error: entry_id required for update operation"
            return await self._update_entry(
                content, memory_path, params.entry_id, params.data, params.description, params.tags
            )
        elif params.operation == "delete":
            if not params.entry_id:
                return "Error: entry_id required for delete operation"
            return await self._delete_entry(content, memory_path, params.entry_id)
        elif params.operation == "append":
            if not params.entry_id:
                return "Error: entry_id required for append operation"
            return await self._append_to_entry(content, memory_path, params.entry_id, params.data)
        else:
            return f"Error: Unknown operation '{params.operation}'"

    def _resolve_path(self, path: Optional[str]) -> Path:
        """Resolve memory file path."""
        if path:
            return Path(path)
        return self.memory_path

    async def _initialize_memory_file(self, memory_path: Path) -> None:
        """Initialize memory file with header."""
        header = f"""# Memory

## metadata

- **version**: "1.0"
- **created**: "{datetime.now(timezone.utc).isoformat()}"
- **updated**: "{datetime.now(timezone.utc).isoformat()}"
- **scope**: "workspace"
- **owner**: "pymolcode-agent"

## lessons

<!-- Store critical lessons learned from mistakes to prevent recurrence -->

## preferences

<!-- Store user preferences and common patterns -->

## knowledge

<!-- Store domain-specific knowledge -->
"""
        memory_path.parent.mkdir(parents=True, exist_ok=True)
        await asyncio.to_thread(memory_path.write_text, header)

    async def _create_entry(
        self,
        content: str,
        memory_path: Path,
        section: Optional[str],
        data: Optional[dict[str, Any]],
        description: Optional[str],
        tags: Optional[list[str]],
    ) -> str:
        """Create a new memory entry."""
        if not section:
            return "Error: section required for create operation"
        if not data:
            return "Error: data required for create operation"

        # Generate entry ID
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M")
        entry_id = f"{section}-{timestamp}"

        # Sanitize data
        sanitized_data = self.policy.sanitize_entry(data)
        sanitized_description = (
            self.policy.redact_sensitive_data(description) if description else None
        )

        # Create entry block
        entry_block = self._format_entry_block(
            entry_id=entry_id,
            created=datetime.now(timezone.utc).isoformat(),
            data=sanitized_data,
            description=sanitized_description,
            tags=tags,
        )

        # Check if section exists
        section_header = f"## {section}"
        if section_header in content:
            # Append to existing section
            new_content = self._insert_into_section(content, section_header, entry_block)
        else:
            # Create new section
            new_content = content.rstrip() + "\n\n" + section_header + "\n" + entry_block

        # Update metadata timestamp
        new_content = self._update_metadata_timestamp(new_content)

        # Write back
        await asyncio.to_thread(memory_path.write_text, new_content)

        return f"Created memory entry: {entry_id} in section: {section}"

    async def _update_entry(
        self,
        content: str,
        memory_path: Path,
        entry_id: str,
        data: Optional[dict[str, Any]],
        description: Optional[str],
        tags: Optional[list[str]],
    ) -> str:
        """Update an existing entry."""
        lines = content.splitlines()
        new_lines: list[str] = []
        found = False
        in_entry = False
        entry_start = -1

        for i, line in enumerate(lines):
            # Check if this is the entry to update
            if line.startswith("### ") and line[4:].strip() == entry_id:
                found = True
                in_entry = True
                entry_start = i
                new_lines.append(line)  # Keep the header
                continue

            # If we're in the entry and hit a new entry/section, stop
            if in_entry and i > entry_start and (line.startswith("## ") or line.startswith("### ")):
                in_entry = False

            # Skip lines within the entry (we'll rebuild it)
            if in_entry:
                continue

            new_lines.append(line)

        if not found:
            return f"Error: Entry not found: {entry_id}"

        # Rebuild the entry with updated data
        if data or description or tags:
            entry_block = self._format_entry_block(
                entry_id=entry_id,
                created="",  # Don't change created timestamp
                data=data or {},
                description=description,
                tags=tags,
                include_header=False,
            )
            # Insert after the entry header
            insert_idx = entry_start + 1
            for line in entry_block.split("\n"):
                new_lines.insert(insert_idx, line)
                insert_idx += 1

        new_content = "\n".join(new_lines)
        new_content = self._update_metadata_timestamp(new_content)

        await asyncio.to_thread(memory_path.write_text, new_content)
        return f"Updated memory entry: {entry_id}"

    async def _delete_entry(self, content: str, memory_path: Path, entry_id: str) -> str:
        """Delete an entry."""
        lines = content.splitlines()
        new_lines: list[str] = []
        found = False
        in_entry = False
        entry_start = -1

        for i, line in enumerate(lines):
            # Check if this is the entry to delete
            if line.startswith("### ") and line[4:].strip() == entry_id:
                found = True
                in_entry = True
                entry_start = i
                continue  # Skip this line

            # If we're in the entry and hit a new entry/section, stop deleting
            if in_entry and i > entry_start and (line.startswith("## ") or line.startswith("### ")):
                in_entry = False

            # Skip lines within the entry
            if in_entry:
                continue

            new_lines.append(line)

        if not found:
            return f"Error: Entry not found: {entry_id}"

        new_content = "\n".join(new_lines)
        new_content = self._update_metadata_timestamp(new_content)

        await asyncio.to_thread(memory_path.write_text, new_content)
        return f"Deleted memory entry: {entry_id}"

    async def _append_to_entry(
        self,
        content: str,
        memory_path: Path,
        entry_id: str,
        data: Optional[dict[str, Any]],
    ) -> str:
        """Append data to an existing entry."""
        if not data:
            return "Error: data required for append operation"

        lines = content.splitlines()
        new_lines: list[str] = []
        found = False
        in_entry = False
        entry_start = -1
        appended = False

        for i, line in enumerate(lines):
            # Check if this is the entry
            if line.startswith("### ") and line[4:].strip() == entry_id:
                found = True
                in_entry = True
                entry_start = i

            # If we're in the entry and hit a new entry/section, append before it
            if in_entry and i > entry_start and (line.startswith("## ") or line.startswith("### ")):
                if not appended:
                    # Append new data fields
                    for key, value in data.items():
                        new_lines.append(f"- **{key}**: {value}")
                    appended = True
                in_entry = False

            new_lines.append(line)

        # If we reached the end while still in entry, append there
        if in_entry and not appended:
            for key, value in data.items():
                new_lines.append(f"- **{key}**: {value}")

        if not found:
            return f"Error: Entry not found: {entry_id}"

        new_content = "\n".join(new_lines)
        new_content = self._update_metadata_timestamp(new_content)

        await asyncio.to_thread(memory_path.write_text, new_content)
        return f"Appended data to memory entry: {entry_id}"

    def _format_entry_block(
        self,
        entry_id: str,
        created: str,
        data: dict[str, Any],
        description: Optional[str],
        tags: Optional[list[str]],
        include_header: bool = True,
    ) -> str:
        """Format an entry block."""
        lines = []

        if include_header:
            lines.append(f"### {entry_id}")

        if created:
            lines.append(f'- **created**: "{created}"')
            lines.append(f'- **updated**: "{datetime.now(timezone.utc).isoformat()}"')

        if tags:
            lines.append(f"- **tags**: {', '.join(tags)}")

        # Add data fields
        for key, value in data.items():
            if isinstance(value, str):
                lines.append(f"- **{key}**: {value}")
            else:
                lines.append(f"- **{key}**: {json.dumps(value)}")

        if description:
            lines.append(f"**Description**: {description}")

        return "\n".join(lines)

    def _insert_into_section(self, content: str, section_header: str, entry_block: str) -> str:
        """Insert entry block into existing section."""
        lines = content.splitlines()
        new_lines: list[str] = []
        inserted = False

        for i, line in enumerate(lines):
            new_lines.append(line)

            # After the section header, find where to insert
            if line == section_header and not inserted:
                # Find the next section or end of file
                for j in range(i + 1, len(lines)):
                    if lines[j].startswith("## "):
                        # Insert before this section
                        new_lines.append("")
                        new_lines.append(entry_block)
                        inserted = True
                        break
                if not inserted:
                    # Insert at end
                    new_lines.append("")
                    new_lines.append(entry_block)
                    inserted = True

        return "\n".join(new_lines)

    def _update_metadata_timestamp(self, content: str) -> str:
        """Update the 'updated' timestamp in metadata section."""
        lines = content.splitlines()
        new_lines: list[str] = []

        for line in lines:
            if line.strip().startswith("- **updated**:"):
                new_lines.append(f'- **updated**: "{datetime.now(timezone.utc).isoformat()}"')
            else:
                new_lines.append(line)

        return "\n".join(new_lines)
