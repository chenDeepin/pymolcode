"""Memory store backend for persistent knowledge storage using YAML."""

from __future__ import annotations

import yaml
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Optional
import time


def ensure_dir(path: Path) -> Path:
    """Ensure directory exists and return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def today_date() -> str:
    """Get today's date in YYYY-MM-DD format."""
    return datetime.now().strftime("%Y-%m-%d")


def today_datetime() -> str:
    """Get current datetime in ISO format."""
    return datetime.now(timezone.utc).isoformat()


class MemoryStore:
    """
    Memory system for the agent using YAML format.

    File Structure:
    ```
    memory/
    ├── memory.yaml           # Main memory (preferences, knowledge)
    ├── lessons.yaml          # Lessons learned from mistakes
    ├── now.yaml              # Active todos and priorities
    └── 2026-02-26.yaml       # Daily session notes
    ```

    YAML Format (memory.yaml):
    ```yaml
    metadata:
      version: "1.0"
      created: "2026-02-26T00:00:00Z"
      updated: "2026-02-26T12:00:00Z"
      scope: workspace
      owner: pymolcode-agent

    preferences:
      visualization:
        theme: dark
        protein: cartoon
        ligand: sticks
        surface: transparent

    knowledge:
      cdk_inhibitors:
        target: CDK4/6
        mechanism: Cell cycle arrest in G1 phase
        clinical: [palbociclib, ribociclib, abemaciclib]
        tags: [drug-discovery, kinases]
    ```
    """

    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.memory_dir = ensure_dir(workspace / "memory")
        self.memory_file = self.memory_dir / "memory.yaml"
        self.lessons_file = self.memory_dir / "lessons.yaml"
        self.now_file = self.memory_dir / "now.yaml"

    def get_today_file(self) -> Path:
        """Get path to today's session file."""
        return self.memory_dir / f"{today_date()}.yaml"

    def _load_yaml(self, path: Path) -> dict[str, Any]:
        """Load YAML file, return empty dict if not exists."""
        if path.exists():
            content = path.read_text(encoding="utf-8")
            return yaml.safe_load(content) or {}
        return {}

    def _save_yaml(self, path: Path, data: dict[str, Any]) -> None:
        """Save data to YAML file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    def read_memory(self) -> dict[str, Any]:
        """Read main memory (memory.yaml)."""
        return self._load_yaml(self.memory_file)

    def write_memory(self, data: dict[str, Any]) -> None:
        """Write to main memory (memory.yaml)."""
        if "metadata" in data:
            data["metadata"]["updated"] = today_datetime()
        self._save_yaml(self.memory_file, data)

    def read_lessons(self) -> dict[str, Any]:
        """Read lessons learned (lessons.yaml)."""
        return self._load_yaml(self.lessons_file)

    def write_lessons(self, data: dict[str, Any]) -> None:
        """Write lessons learned (lessons.yaml)."""
        self._save_yaml(self.lessons_file, data)

    def add_lesson(
        self,
        lesson: str,
        context: str,
        fix: str,
        tags: Optional[list[str]] = None,
        category: str = "general",
    ) -> str:
        """Add a new lesson to lessons.yaml."""
        data = self.read_lessons()

        if "lessons" not in data:
            data["lessons"] = []

        lesson_id = f"lesson-{today_date()}-{len(data['lessons']) + 1:03d}"

        entry = {
            "id": lesson_id,
            "created": today_datetime(),
            "category": category,
            "tags": tags or [],
            "lesson": lesson,
            "context": context,
            "fix": fix,
        }

        data["lessons"].append(entry)
        self.write_lessons(data)

        return lesson_id

    def read_now(self) -> dict[str, Any]:
        """Read active todos (now.yaml)."""
        return self._load_yaml(self.now_file)

    def write_now(self, data: dict[str, Any]) -> None:
        """Write active todos (now.yaml)."""
        self._save_yaml(self.now_file, data)

    def add_todo(
        self,
        task: str,
        priority: str = "P2",
        status: str = "pending",
        tags: Optional[list[str]] = None,
    ) -> str:
        """Add a new todo to now.yaml."""
        data = self.read_now()

        if "active_todos" not in data:
            data["active_todos"] = []

        todo_id = str(int(time.time()))

        entry = {
            "id": todo_id,
            "task": task,
            "priority": priority,
            "status": status,
            "tags": tags or [],
            "created": today_datetime(),
        }

        data["active_todos"].append(entry)
        self.write_now(data)

        return todo_id

    def complete_todo(self, todo_id: str) -> bool:
        """Mark a todo as completed."""
        data = self.read_now()

        if "active_todos" not in data:
            return False

        for todo in data["active_todos"]:
            if todo.get("id") == todo_id:
                todo["status"] = "completed"
                todo["completed"] = today_datetime()
                self.write_now(data)
                return True

        return False

    def read_today(self) -> dict[str, Any]:
        """Read today's session notes."""
        return self._load_yaml(self.get_today_file())

    def append_today(
        self, event_type: str, content: str, metadata: Optional[dict[str, Any]] = None
    ) -> None:
        """Append an event to today's session notes."""
        data = self.read_today()

        if "metadata" not in data:
            data["metadata"] = {
                "date": today_date(),
                "created": today_datetime(),
            }

        if "events" not in data:
            data["events"] = []

        entry: dict[str, Any] = {
            "time": datetime.now().strftime("%H:%M"),
            "type": event_type,
            "content": content,
        }
        if metadata:
            entry["metadata"] = dict(metadata)

        events_list = data.get("events", [])
        events_list.append(entry)
        data["events"] = events_list
        self._save_yaml(self.get_today_file(), data)

    def get_recent_sessions(self, days: int = 7) -> list[dict[str, Any]]:
        """Get session data from the last N days."""
        sessions = []
        today = datetime.now().date()

        for i in range(days):
            date = today - timedelta(days=i)
            date_str = date.strftime("%Y-%m-%d")
            file_path = self.memory_dir / f"{date_str}.yaml"

            if file_path.exists():
                data = self._load_yaml(file_path)
                data["_date"] = date_str
                sessions.append(data)

        return sessions

    def list_memory_files(self) -> list[Path]:
        """List all session files sorted by date (newest first)."""
        if not self.memory_dir.exists():
            return []

        files = list(self.memory_dir.glob("????-??-??.yaml"))
        return sorted(files, reverse=True)

    def get_memory_context(self, include_lessons: bool = True, include_todos: bool = False) -> str:
        """
        Get memory context formatted for the agent system prompt.

        Returns:
            Formatted memory context as a string.
        """
        parts = []

        memory = self.read_memory()
        if memory:
            prefs = memory.get("preferences", {})
            if prefs:
                parts.append("## Preferences\n" + yaml.safe_dump(prefs, default_flow_style=False))

            knowledge = memory.get("knowledge", {})
            if knowledge:
                parts.append("## Knowledge\n" + yaml.safe_dump(knowledge, default_flow_style=False))

        if include_lessons:
            lessons_data = self.read_lessons()
            lessons = lessons_data.get("lessons", [])
            if lessons:
                lessons_text = "## Lessons Learned (CRITICAL - Read These!)\n"
                for lesson in lessons[-10:]:
                    lessons_text += f"\n### {lesson.get('id', 'unknown')}\n"
                    lessons_text += f"- **Lesson**: {lesson.get('lesson', '')}\n"
                    lessons_text += f"- **Context**: {lesson.get('context', '')}\n"
                    lessons_text += f"- **Fix**: {lesson.get('fix', '')}\n"
                    if lesson.get("tags"):
                        lessons_text += f"- **Tags**: {', '.join(lesson['tags'])}\n"
                parts.append(lessons_text)

        if include_todos:
            now_data = self.read_now()
            todos = now_data.get("active_todos", [])
            pending = [t for t in todos if t.get("status") != "completed"]
            if pending:
                todos_text = "## Active Todos\n"
                for todo in pending:
                    todos_text += f"- [{todo.get('priority', 'P2')}] {todo.get('task', '')}\n"
                parts.append(todos_text)

        today_data = self.read_today()
        events = today_data.get("events", [])
        if events:
            events_text = "## Today's Session\n"
            for event in events[-20:]:
                events_text += f"- [{event.get('time', '??:??')}] {event.get('type', 'unknown')}: {event.get('content', '')}\n"
            parts.append(events_text)

        return "\n\n".join(parts) if parts else ""

    def initialize_if_missing(self) -> None:
        """Initialize memory files if they don't exist."""
        if not self.memory_file.exists():
            initial_memory = {
                "metadata": {
                    "version": "1.0",
                    "created": today_datetime(),
                    "updated": today_datetime(),
                    "scope": "workspace",
                    "owner": "pymolcode-agent",
                },
                "preferences": {
                    "visualization": {
                        "theme": "dark",
                        "protein": "cartoon",
                        "ligand": "sticks",
                        "surface": "transparent",
                    },
                    "workflow": {
                        "verify_operations": True,
                        "honest_reporting": True,
                    },
                },
                "knowledge": {},
            }
            self._save_yaml(self.memory_file, initial_memory)

        if not self.lessons_file.exists():
            initial_lessons = {
                "metadata": {
                    "version": "1.0",
                    "created": today_datetime(),
                },
                "lessons": [
                    {
                        "id": "lesson-pymol-verification-001",
                        "created": today_datetime(),
                        "category": "pymol",
                        "tags": ["critical", "verification"],
                        "lesson": "Always verify PyMOL load operations by checking object list",
                        "context": "Agent reported successful load when pymol_load actually failed",
                        "fix": "After any pymol_load, call pymol_list to verify the object exists",
                    },
                    {
                        "id": "lesson-honest-reporting-001",
                        "created": today_datetime(),
                        "category": "general",
                        "tags": ["critical", "honesty"],
                        "lesson": "Report failures honestly, never make false success claims",
                        "context": "Made excuses about PDB accessibility instead of reporting actual error",
                        "fix": "Check function results against observable evidence before reporting",
                    },
                ],
            }
            self._save_yaml(self.lessons_file, initial_lessons)

        if not self.now_file.exists():
            initial_now = {
                "metadata": {
                    "version": "1.0",
                    "updated": today_datetime(),
                },
                "active_todos": [],
            }
            self._save_yaml(self.now_file, initial_now)

    def search_lessons(self, query: str, tags: Optional[list[str]] = None) -> list[dict[str, Any]]:
        """Search lessons by query or tags."""
        data = self.read_lessons()
        lessons = data.get("lessons", [])

        results = []
        query_lower = query.lower() if query else ""

        for lesson in lessons:
            matches_query = not query or (
                query_lower in lesson.get("lesson", "").lower()
                or query_lower in lesson.get("context", "").lower()
                or query_lower in lesson.get("fix", "").lower()
            )

            matches_tags = not tags or any(tag in lesson.get("tags", []) for tag in tags)

            if matches_query and matches_tags:
                results.append(lesson)

        return results
