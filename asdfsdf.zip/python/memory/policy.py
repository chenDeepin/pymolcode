"""Memory policy enforcement for security and resource limits.

This module validates and sanitizes memory entries to prevent:
- Oversized entries that could degrade performance
- Sensitive data leakage (API keys, passwords, etc.)
- Resource exhaustion from too many entries
"""

from __future__ import annotations

import re
from typing import Any


class MemoryPolicy:
    """Enforces memory storage policies."""

    # Policy constants
    MAX_ENTRY_SIZE = 10240  # 10KB per entry
    MAX_FILE_SIZE = 1048576  # 1MB per file
    MAX_ENTRIES_PER_SECTION = 100
    MAX_TOTAL_ENTRIES = 1000

    # Sensitive key names (always redact their values)
    SENSITIVE_KEYS = {
        "password",
        "api_key",
        "apikey",
        "api-key",
        "secret",
        "token",
        "bearer_token",
        "ssn",
        "social_security",
        "credit_card",
        "authorization",
        "auth_token",
        "access_token",
        "private_key",
        "credential",
        "credential_token",
    }

    # Sensitive data patterns for redaction
    SENSITIVE_PATTERNS = [
        (r'"password"["\']?\s*:\s*["\']?[^"\'\s,}]+', "[REDACTED: password]"),
        (r'"api[_-]?key"["\']?\s*:\s*["\']?[^"\'\s,}]+', "[REDACTED: api_key]"),
        (r'"secret"["\']?\s*:\s*["\']?[^"\'\s,}]+', "[REDACTED: secret]"),
        (r'"token"["\']?\s*:\s*["\']?[^"\'\s,}]+', "[REDACTED: token]"),
        (r'password["\']?\s*[:=]\s*["\']?[^"\'\s]+', "[REDACTED: password]"),
        (r'api[_-]?key["\']?\s*[:=]\s*["\']?[^"\'\s]+', "[REDACTED: api_key]"),
        (r'secret["\']?\s*[:=]\s*["\']?[^"\'\s]+', "[REDACTED: secret]"),
        (r'token["\']?\s*[:=]\s*["\']?[^"\'\s]+', "[REDACTED: token]"),
        (r"Bearer\s+[A-Za-z0-9\-._~+/]+", "[REDACTED: bearer_token]"),
        (r"sk-[A-Za-z0-9]{20,}", "[REDACTED: api_key]"),
        (r"(?:\d{3}-){2}\d{4}", "[REDACTED: ssn]"),
        (r"\b\d{16}\b", "[REDACTED: credit_card]"),
    ]

    def __init__(
        self,
        max_entry_size: int = MAX_ENTRY_SIZE,
        max_file_size: int = MAX_FILE_SIZE,
        max_entries_per_section: int = MAX_ENTRIES_PER_SECTION,
        redact_sensitive: bool = True,
    ) -> None:
        """
        Initialize memory policy.

        Args:
            max_entry_size: Maximum size per entry in bytes
            max_file_size: Maximum file size in bytes
            max_entries_per_section: Maximum entries per section
            redact_sensitive: Whether to redact sensitive data
        """
        self.max_entry_size = max_entry_size
        self.max_file_size = max_file_size
        self.max_entries_per_section = max_entries_per_section
        self.redact_sensitive = redact_sensitive

    def check_entry_size(self, entry: dict) -> tuple[bool, str | None]:
        """
        Check if entry size is within limits.

        Args:
            entry: Entry dictionary to check

        Returns:
            (is_valid, error_message)
        """
        entry_str = str(entry)
        size = len(entry_str.encode("utf-8"))

        if size > self.max_entry_size:
            return (
                False,
                f"Entry size ({size} bytes) exceeds limit ({self.max_entry_size} bytes)",
            )

        return True, None

    def check_file_size(self, file_size: int) -> tuple[bool, str | None]:
        """
        Check if file size is within limits.

        Args:
            file_size: File size in bytes

        Returns:
            (is_valid, error_message)
        """
        if file_size > self.max_file_size:
            return (
                False,
                f"File size ({file_size} bytes) exceeds limit ({self.max_file_size} bytes)",
            )

        return True, None

    def check_entry_count(self, entries: list[dict], section: str) -> tuple[bool, str | None]:
        """
        Check if section has too many entries.

        Args:
            entries: List of entries in section
            section: Section name

        Returns:
            (is_valid, error_message)
        """
        section_entries = [e for e in entries if e.get("section") == section]

        if len(section_entries) >= self.max_entries_per_section:
            return (
                False,
                f"Section '{section}' has {len(section_entries)} entries, "
                f"exceeding limit ({self.max_entries_per_section})",
            )

        return True, None

    def redact_sensitive_data(self, text: str) -> str:
        """
        Redact sensitive data from text.

        Args:
            text: Text to redact

        Returns:
            Redacted text
        """
        if not self.redact_sensitive:
            return text

        redacted = text
        for pattern, replacement in self.SENSITIVE_PATTERNS:
            redacted = re.sub(pattern, replacement, redacted, flags=re.IGNORECASE)

        return redacted

    def sanitize_entry(self, entry: dict) -> dict:
        """
        Sanitize entry by redacting sensitive data.

        Args:
            entry: Entry dictionary to sanitize

        Returns:
            Sanitized entry dictionary
        """
        sanitized = {}

        for key, value in entry.items():
            if key.lower() in self.SENSITIVE_KEYS:
                # Redact entire value for sensitive keys
                if isinstance(value, str):
                    sanitized[key] = f"[REDACTED: {key}]"
                elif isinstance(value, dict):
                    sanitized[key] = {k: f"[REDACTED: {k}]" for k, v in value.items()}
                elif isinstance(value, list):
                    sanitized[key] = ["[REDACTED]" for _ in value]
                else:
                    sanitized[key] = f"[REDACTED: {key}]"
            elif isinstance(value, str):
                sanitized[key] = self.redact_sensitive_data(value)
            elif isinstance(value, dict):
                sanitized[key] = self.sanitize_entry(value)
            elif isinstance(value, list):
                sanitized[key] = [
                    self.redact_sensitive_data(v) if isinstance(v, str) else v for v in value
                ]
            else:
                sanitized[key] = value

        return sanitized

    def validate_entry(self, entry: dict, existing_entries: list[dict]) -> tuple[bool, str | None]:
        """
        Validate entry against all policies.

        Args:
            entry: Entry dictionary to validate
            existing_entries: List of existing entries

        Returns:
            (is_valid, error_message)
        """
        # Check size
        is_valid, error = self.check_entry_size(entry)
        if not is_valid:
            return False, error

        # Check section count
        section = entry.get("section", "")
        is_valid, error = self.check_entry_count(existing_entries, section)
        if not is_valid:
            return False, error

        return True, None
