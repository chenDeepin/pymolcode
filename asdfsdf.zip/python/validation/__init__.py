"""Validation module for pymolcode."""

from __future__ import annotations
